package com.example.project2.data

import com.google.firebase.Timestamp
import java.time.Duration
import java.time.Instant
import java.util.UUID

/**
 * Lightweight data models representing the core entities in MindMatch.
 * These will eventually be backed by a repository (Firebase/local DB),
 * but for now they describe the state the UI needs to render.
 */
data class PlayerProfile(
    val id: String = UUID.randomUUID().toString(),
    val displayName: String = "Player",
    val avatarUrl: String? = null,
    val bio: String = "",
    val preferredDifficulty: Difficulty = Difficulty.MEDIUM,
    val createdAt: Timestamp = Timestamp.now(),
    val puzzlesPlayed: Map<String, Timestamp> = emptyMap()
)

/** Describes a puzzle shown in the app. */
data class PuzzleDescriptor(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val description: String,
    val type: PuzzleType,
    val gridSize: Int? = null,
    val creatorId: String,
    val difficulty: Difficulty,
    val estimatedDuration: Duration = Duration.ofMinutes(2),
    val isUserCreated: Boolean = false,
    val imageName: String? = null,
    val imageUrl: String? = null,
    val localImageResId: Int? = null,
    val lastPlayed: Instant? = null,
    val mastermindConfig: MastermindConfig? = null
)

/** Per-user progress for a puzzle. */
data class PuzzleProgress(
    val puzzleId: String,
    val currentLevel: Int,
    val levelsUnlocked: Int,
    val bestScore: Int,
    val bestTime: Duration?,
    val inProgressState: String? = null
)

/** Leaderboard entry for a puzzle. */
data class LeaderboardEntry(
    val puzzleId: String,
    val playerName: String,
    val score: Int,
    val recordedAt: Instant
)

/** Daily challenge bundle. */
data class DailyChallenge(
    val puzzle: PuzzleDescriptor,
    val expiresAt: Instant,
    val content: DailyPuzzleContent
)

/** Supported puzzle types. */
enum class PuzzleType(val displayName: String) {
    PATTERN_MEMORY("Pattern Memory"),
    LOGIC_GRID("Logic Grid"),
    SEQUENCE_RECALL("Sequence Recall"),
    FOCUS_TAPPER("Focus Tapper"),
    SPEED_MATCH("Speed Match"),
    JIGSAW("Jigsaw Puzzle"),
    MASTERMIND("Mastermind")
}

/** Puzzle difficulty levels. */
enum class Difficulty {
    EASY, MEDIUM, HARD, EXPERT
}

/** Content for a daily puzzle (grid, controls, stats). */
data class DailyPuzzleContent(
    val instructions: String,
    val grid: List<List<PuzzleCell>>,
    val controls: List<PuzzleControl>,
    val stats: PuzzleStats
)

/** A single cell in a grid-based puzzle. */
data class PuzzleCell(
    val value: String,
    val state: PuzzleCellState = PuzzleCellState.Neutral
)

/** Possible cell states. */
enum class PuzzleCellState {
    Neutral,
    Active,
    Correct,
    Incorrect,
    Disabled
}

/** Control button definition for a puzzle. */
data class PuzzleControl(
    val id: String,
    val label: String,
    val isPrimary: Boolean = false
)

/** Stats for a daily puzzle session. */
data class PuzzleStats(
    val target: Int,
    val streak: Int,
    val timeRemainingSeconds: Int
)

/** Configuration for Mastermind puzzles. */
data class MastermindConfig(
    val colors: List<String>,
    val slots: Int,
    val guesses: Int,
    val levels: Int,
    val code: List<String>
)
